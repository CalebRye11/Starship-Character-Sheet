BUG WAR DIGITAL COMPANION — PWA v1

This is V8 with installability, mobile navigation, and offline asset caching. V8 mechanics and existing character save keys remain unchanged.

DEPLOYMENT (required for phone installation):
1. Upload the contents of this folder to an HTTPS static website (for example GitHub Pages, Netlify, or Cloudflare Pages). Keep the folder structure intact.
2. Open the HTTPS URL in Safari on iPhone or Chrome on Android.
3. iPhone: Share > Add to Home Screen > Add. Android: menu > Install app / Add to Home screen.
4. Open from the icon. Visit online once before relying on offline use.

Opening index.html directly from a ZIP/file:// path does not install the PWA or enable offline service worker.

SAVE DATA: Character data remains in localStorage on each device. No automatic cross-device sync. Use Export Character JSON to back up and Import to transfer. Clearing site data may delete saved characters.

This is a fan-made game companion; not an official licensed product.
